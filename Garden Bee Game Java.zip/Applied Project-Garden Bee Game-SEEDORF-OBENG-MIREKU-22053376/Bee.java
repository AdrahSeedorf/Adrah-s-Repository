import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This class defines a bee. Bee live in the garden. They like flower nectar 
 * 
 * 
 * Version: 5
 * 
 * In this version, the bee behaves as before, but we add animation of the 
 * image.
 */
public class Bee extends Actor
{
    private GreenfootImage image1;
    private GreenfootImage image2;
    private int nectarEaten;
    /**
     * Create a bee and initialize its two images.
     */
    public Bee()
    {
        image1 = new GreenfootImage("bee.png");
        image2 = new GreenfootImage("bee2.png");
        setImage(image1);
        nectarEaten = 0;
    }
    /** 
     * Act - do whatever the bee wants to do. This method is called whenever
     *  the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        checkKeypress();
        lookForNectar();
        switchImage();
        turnAtEdge();
    }
    /**
     * Alternate the bee's image between image1 and image2.
     */
    public void switchImage()
    {
        if (getImage() == image1) 
        {
            setImage(image2);
        }
        else
        {
            setImage(image1);
        }
    }
    /**
     * Check whether a control key on the keyboard has been pressed.
     * If it has, react accordingly.
     */
    public void checkKeypress()
    {
        if (Greenfoot.isKeyDown("left"))
        {
           setLocation(getX() - 1, getY());//When the user presses the left arrow key, the position of the bee on the x-axis is reduced by 1 unit causing the bee to move towards the left.
        }
        if (Greenfoot.isKeyDown("right"))
        {
            setLocation(getX() + 1, getY());//When the user presses the right arrow key, the position of the bee on the x-axis is increased by 1 unit causing the bee to move towards the right.
        }
        if (Greenfoot.isKeyDown("up"))
        {
           setLocation(getX(), getY() - 1); //When the user presses the up arrow key, the position of the bee on the y-axis is reduced by 1 unit causing the bee to move upward.
        }
        if (Greenfoot.isKeyDown("down"))
        {
            setLocation(getX(), getY() + 1);//When the user presses the bottom arrow key, the position of the bee on the y-axis is increased by 1 unit causing the bee to move downward.
        }
    }
    /**
     * Check whether we have stumbled upon a FlowerNectar.
     * If we have, eat it. If not, do nothing. If we have
     * eaten more than 5 FlowerNectars, we win.
     */
    public void lookForNectar()
    {
        if ( isTouching(FlowerNectar.class) ) 
        {
            Greenfoot.playSound("slurp.wav");//This function generates the slurp sound when the bee touches the flower nectar.
            removeTouching(FlowerNectar.class);//Any flower nectar which is touched by the bee is removed from the grid by this function.
            nectarEaten++;
            if(nectarEaten >= 5)//When the bee touches five or more flower nectars, the user is adjuged the winner of the game.
            {
                System.out.println("User has won the game");
                if((nectarEaten%2)==0)
                {
                    System.out.println("That's not odd");//When the flowers eaten is an even number, this statement is printed to the console.
                }
                else if((nectarEaten%2)!=0)
                {
                    System.out.println("That's odd");//When the flowers eaten is an odd number, this statement is printed to the console.
                }
                Greenfoot.stop();//The game stops once the bee touches five or more flower nectars.
            }
        }
    }
    public void turnAtEdge()
    {
        if( isAtEdge() )
        {
           turn(1);//This function causes the bee to turn by 1 unit whenever the bee reaches the edge of the grid.
        }
    }
}
