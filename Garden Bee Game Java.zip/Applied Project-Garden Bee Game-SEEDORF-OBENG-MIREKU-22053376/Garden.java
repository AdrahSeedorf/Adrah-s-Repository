import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Garden here.
 * 
 * @author (SEEDORF OBENG-MIREKU) 
 * @version (19/01/2024)
 */
public class Garden extends World
{

    /**
     * Create the Bear world (the garden). Our world has a size 
     * of 600x600 cells, where every cell is just 1 pixel.
     */
    public Garden()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 600, 1);
        prepare();
    }
    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        Bee Bee = new Bee();
        addObject(Bee, 100, 100);//The bee is placed on the grid as the main actor.
        int [] arrayX = new int[10];//arrayX serves as x-coordinate values on the grid.
        int [] arrayY = new int[10];//arrayY acts as y-coordinate values on the grid.
        for(int i=0; i<arrayX.length; i++)
        {
            int numberX = Greenfoot.getRandomNumber(600);//Random value between 0 and 600 is generated and stored in arrayX.
            arrayX[i] = numberX;
            int numberY = Greenfoot.getRandomNumber(600);//Random value between 0 and 600 is generated and stored in arrayY.
            arrayY[i] = numberY;
            FlowerNectar FlowerNectar = new FlowerNectar();
            addObject(FlowerNectar, arrayX[i], arrayY[i]);//FlowerNectar object is placed on the grid according to coordinated provided by arrayX and arraY.
        }
        Bear Bear = new Bear();
        addObject(Bear, 334, 45);
        Bear Bear2 = new Bear();
        addObject(Bear2, 481, 481);
        Bear Bear3 = new Bear();
        addObject(Bear3, 79, 270);
    }
}
