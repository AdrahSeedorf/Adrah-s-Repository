import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * A Bear. Bear live in the forests. They like to eat bees. (Well, in our game
 * they live in our garden...)
 * 
 * Version: 2
 * 
 * The bear walks around randomly. If it runs into a bee it eats it.
 *
 */
public class Bear extends Actor
{
    /**
     * Do whatever Bears do.
     */
    public void act()
    {
        turnAtEdge();
        randomTurn();
        move(5);
        lookForBee();
    }
    /**
     * Check whether we are at the edge of the world. If we are, turn a bit.
     * If not, do nothing.
     */
    public void turnAtEdge()
    {
        if ( isAtEdge() ) 
        {
            turn(17);
        }
    }
    /**
     * Randomly decide to turn from the current direction, or not. If we turn
     * turn a bit left or right by a random degree.
     */
    public void randomTurn()
    {
        if (Greenfoot.getRandomNumber(100) > 90) 
        {
            turn(Greenfoot.getRandomNumber(90)-45);
        }
    }
    /**
     * Try to catch a bee. That is: check whether we have stumbled upon a bee.
     * If we have, remove the bee from the game, and stop the program running.
     */
    public void lookForBee()
    {
        if ( isTouching(Bee.class) ) 
        {
            removeTouching(Bee.class);
            System.out.println("User has lost the game");
            System.out.println("Bear: Bee was eaten at grid cell " + getX() + " " + getY() + ".");//The position where the bee was touched by the bear is printed to the console.
            Greenfoot.stop();//This function stops the game once the bear touches the bee.
        }
    }
}
