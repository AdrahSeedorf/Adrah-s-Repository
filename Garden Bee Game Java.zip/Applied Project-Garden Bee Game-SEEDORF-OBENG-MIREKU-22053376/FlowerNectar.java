import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * FlowerNectar. Nectar of flower. Very yummy. Especially bees really like it.
 */
public class FlowerNectar extends Actor
{
    
}
